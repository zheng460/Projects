package com.example.shirongzheng.cs180project;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.*;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static ArrayList<Counter> counters=new ArrayList<Counter>();
    //@Override
    private Button addnew;
    private Button auto;
    private static int ctn=0;
    private ListView listview;
    public static int index=0;
    public static ArrayList<String> counternames=new ArrayList<>();
    private ArrayAdapter listAdapter;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addnew=(Button)findViewById(R.id.btnaddnew);
        auto=(Button)findViewById(R.id.btnauto);
        listview = (ListView)findViewById(R.id.listviewnew);
        if (counternames.size()==0){
            Counter counter=new Counter();
            counters.add(counter);
            String number;
            number=String.valueOf(counter.getCount());
            counternames.add(counter.getName()+": "+number);
            index++;
        }else {
            for (int i=0;i<counters.size();i++) {
                counternames.set(i, counters.get(i).getName() + ": " + String.valueOf(counters.get(i).getCount()));
            }
        }

        addnew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                /*Integer.toString(ctn);
                Counter String*/
                Counter counter=new Counter(index);
                counters.add(counter);
                index++;
                listview.deferNotifyDataSetChanged();
                Intent intent=new Intent(view.getContext(),AddNew.class);
                startActivity(intent);
                //listview.
            }
        });

        listAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,counternames);
        listview.setAdapter(listAdapter);
        listAdapter.notifyDataSetChanged();
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                int count;
                count=counters.get(i).getCount();
                Intent intent=new Intent(view.getContext(),Counter.class);
                intent.putExtra("send",i);
                startActivity(intent);

            }
        });
        auto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for (int i = 0; i <counters.size() ; i++) {
                    counters.get(i).setCount(counters.get(i).getCount()+1);
                }
                for (int i=0;i<counters.size();i++) {
                    counternames.set(i, counters.get(i).getName() + ": " + String.valueOf(counters.get(i).getCount()));
                }
                listview.setAdapter(listAdapter);
            }
        });
    }

    //counter.setOnClickListener(new View.OnClickListener())
}
