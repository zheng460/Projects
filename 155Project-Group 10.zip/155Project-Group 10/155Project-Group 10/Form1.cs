﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

/*=========================================================
* Group 10
* Name: Lin Sun Fa, Qingyuan(Carol) Hu, Yilin(Cindy) Hou, Tyler Hewwitt, Shirong(Peter) Zheng(volunteer to help)
* Email: hu528@purdue.edu
* Description: Game--How to go across the river
* Academic Honesty: 
*	I attest that this is my original work.
*	I have not used unauthorized source code, either modified or unmodified.
*	I have not given other fellow student(s) access to my program.
*=========================================================== */

namespace _155Project_Group_10
{
    public partial class form : Form
    {
       
        public form()
        {
            InitializeComponent();
        }

        private const int csize1 = 3;//size of human array and monster array
        private const int csize2 = 20;//size of database
        private string[] aMonster = new string[csize1];
        private string[] aHuman = new string[csize1];
        private string[] aNameRecord = new string[csize2];
        private string[] aDifficultyRecord = new string[csize2];
        private int[] aTimeRecord = new int[csize2];
        private int[] aTimeRecord2 = new int[csize2];
        private int mIndexRecord = 0;
        private int step;//movement of boat
        private int time=0;
        private int boatFlag=0;//direction of boat moving
        private int M1flag = 0, M2flag = 0, M3flag = 0, H1flag = 0, H2flag = 0, H3flag = 0;//human and monster boat boarding or leaving
        private int flag = 0;// win or lose
        private Point location;
        private string mfile = Path.Combine//file location//
           (Application.StartupPath, "Student.txt");
        private string picMonsterAsian = Path.Combine(Application.StartupPath, "pictures\\monster2.png");
        private string picMonsterAmerican = Path.Combine(Application.StartupPath, "pictures\\monster.png");

        //location of the initial humans and monsters
        private Point locationRightM1 = new Point(946, 361);
        private Point locationRightM2 = new Point(893, 361);
        private Point locationRightM3 = new Point(841, 361);
        private Point locationRightH1 = new Point(998, 380);
        private Point locationRightH2 = new Point(1040, 380);
        private Point locationRightH3 = new Point(1082, 380);

        //location of the left side human and monster
        private Point locationLeftM1 = new Point(15, 361);
        private Point locationLeftM2 = new Point(67, 361);
        private Point locationLeftM3 = new Point(120, 361);
        private Point locationLeftH1 = new Point(172, 380);
        private Point locationLeftH2 = new Point(214, 380);
        private Point locationLeftH3 = new Point(256, 380);

        //location of the humans and monsters on the boat
        private Point location4M = new Point(716, 361);
        private Point location5M = new Point(769, 361);
        private Point location4H = new Point(716, 380);
        private Point location5H = new Point(769, 380);
        private Point location1M = new Point(316, 361);
        private Point location2M = new Point(369, 361);
        private Point location1H = new Point(316, 380);
        private Point location2H = new Point(369, 380);


        //message box of error message
        private void DisplayMessage(string str)
        {
            MessageBox.Show(str, Text, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        //validate input
        private bool ValidateInput()
        {
            if (txtName.Text == "")
            {
                DisplayMessage("Enter a name!");
                txtName.Focus();
                return false;
            }

            if (cboMode.Text == "")
            {
                DisplayMessage("Select a mode!!!!!!");
                return false;
            }

            if (radAmerican.Checked == false && radAsian.Checked == false)
            {
                DisplayMessage("Select a style!!!!!!!!!!");
                return false;
            }

            return true;
        }

        //judge the winning or losing of game
        private bool algorithm()
        {
            int i;
            int H012 = 0;//count of number of humans on site 012
            //int H3 = 0;//3
            int H456 = 0;//456
            int M012 = 0;//count of number of monsters on site 012
            //int M3 = 0;//3
            int M456 = 0;//456

            //processing of counting
            for (i = 0; i < 3; i++)
            {
                H012 = H012 + int.Parse(aHuman[i].Substring(0, 1)) + int.Parse(aHuman[i].Substring(1, 1)) + int.Parse(aHuman[i].Substring(2, 1));
                M012 = M012 + int.Parse(aMonster[i].Substring(0, 1)) + int.Parse(aMonster[i].Substring(1, 1)) + int.Parse(aMonster[i].Substring(2, 1));
                H456 = H456 + int.Parse(aHuman[i].Substring(4, 1)) + int.Parse(aHuman[i].Substring(5, 1)) + int.Parse(aHuman[i].Substring(6, 1));
                M456 = M456 + int.Parse(aMonster[i].Substring(4, 1)) + int.Parse(aMonster[i].Substring(5, 1)) + int.Parse(aMonster[i].Substring(6, 1));
                //H3 = H3 + int.Parse(aHuman[i].Substring(3, 1));
                //M3= M3 + int.Parse(aMonster[i].Substring(3, 1));
            }

            //compare the number of humans and monsters on boths sides
            if (H012 < M012 && H012!=0)
            {
                timer2.Enabled = false;

                DisplayMessage("Human is dead QAQQQQQQ");

                picBoat.Enabled = false;
                picH1.Enabled = false;
                picH2.Enabled = false;
                picH3.Enabled = false;
                picM1.Enabled = false;
                picM2.Enabled = false;
                picM3.Enabled=false;

                return false;
            }
            if (H456 < M456 && H456!=0)
            {
                timer2.Enabled = false;

                DisplayMessage("Human is dead QAQQQQQQ");

                picBoat.Enabled = false;
                picH1.Enabled = false;
                picH2.Enabled = false;
                picH3.Enabled = false;
                picM1.Enabled = false;
                picM2.Enabled = false;
                picM3.Enabled = false;

                return false;
            }

            flag = 0;

            //criteria for winning only,only if when all the values for humans are "1000000"
            for (i = 0; i <= cboMode.SelectedIndex; i++)
            {
                if (aHuman[i] == "1000000" && aMonster[i]=="1000000")
                {
                    flag++;
                }
                else
                {
                    flag = 0;
                }
            }



            if (flag == cboMode.SelectedIndex+1)
            {
                timer2.Enabled = false;
                aTimeRecord[mIndexRecord] = time;
                aTimeRecord2[mIndexRecord] = time;
                mIndexRecord++;

                DisplayMessage("Congratulations! You win!");

                picBoat.Enabled = false;
                picH1.Enabled = false;
                picH2.Enabled = false;
                picH3.Enabled = false;
                picM1.Enabled = false;
                picM2.Enabled = false;
                picM3.Enabled = false;

                return false;
            }

            return true;
        }

        //for the moving of boat from right to left
        /*private int boatPlacement45()
        {
            int i, p4 = 0, p5 = 0;
            for (i = 0; i < 3; i++)
            {
                p4 = p4 + int.Parse(aHuman[i].Substring(4, 1)) + int.Parse(aMonster[i].Substring(4, 1));
                p5 = p5 + int.Parse(aHuman[i].Substring(5, 1)) + int.Parse(aMonster[i].Substring(5, 1));
            }

            if (p4 == 0)
            {
                return 4;
            }
            else if (p5 == 0)
            {
                return 5;
            }
            else
            {
                DisplayMessage("The boat is full!!!!!");
                return 0;
            }
        }

        //for the moving of boat from left to right
        private int boatPlacement12()
        {
            int i, p1 = 0, p2 = 0;
            for (i = 0; i < 3; i++)
            {
                p1 = p1 + int.Parse(aHuman[i].Substring(1, 1)) + int.Parse(aMonster[i].Substring(1, 1));
                p2 = p2 + int.Parse(aHuman[i].Substring(2, 1)) + int.Parse(aMonster[i].Substring(2, 1));
            }

            if (p1 == 0)
            {
                return 1;//
            }
            else if (p2 == 0)
            {
                return 2;
            }
            else
            {
                DisplayMessage("The boat is full!!!!!");
                return 0;
            }
        }
        */

        private void picBoat_Click_1(object sender, EventArgs e)
        {
            //debug
            picBoat.Enabled = false;
            picH1.Enabled = false;
            picH2.Enabled = false;
            picH3.Enabled = false;
            picM1.Enabled = false;
            picM2.Enabled = false;
            picM3.Enabled = false;

            if (M1flag == 0 && M2flag == 0 && M3flag == 0 && H1flag == 0 && H2flag == 0 && H3flag == 0)
            {
                picBoat.Enabled = true;
                picH1.Enabled = true;
                picH2.Enabled = true;
                picH3.Enabled = true;
                picM1.Enabled = true;
                picM2.Enabled = true;
                picM3.Enabled = true;
            }
           
            //count of the number of object on the boat
            int j;
            int l4 = 0, l5 = 0, l1 = 0, l2 = 0;
            for (j = 0; j < 3; j++)
            {
                l1 = l1 + int.Parse(aHuman[j].Substring(1, 1)) + int.Parse(aMonster[j].Substring(1, 1));
                l2 = l2 + int.Parse(aHuman[j].Substring(2, 1)) + int.Parse(aMonster[j].Substring(2, 1));
                l4 = l4 + int.Parse(aHuman[j].Substring(4, 1)) + int.Parse(aMonster[j].Substring(4, 1));
                l5 = l5 + int.Parse(aHuman[j].Substring(5, 1)) + int.Parse(aMonster[j].Substring(5, 1));
            }

            //move the boat
            if (boatFlag==0)
            {
                if (l4 == 1 || l5 == 1)
                {
                    timer1.Enabled = true;
                    step = 0;
                }
            }
            else if(boatFlag==1)
            {
                if (l1 == 1 || l2 == 1)
                {
                    timer1.Enabled = true;
                    step = 0;
                }
            }    
        }


        private void btnStart_Click(object sender, EventArgs e)
        {
            btnReset.PerformClick();
            if (ValidateInput()==false)
            {
                return;
            }

            //choose the picture style
            if (radAsian.Checked==true)
            {
                picM1.Image = System.Drawing.Image.FromFile(picMonsterAsian);
                picM2.Image = System.Drawing.Image.FromFile(picMonsterAsian);
                picM3.Image = System.Drawing.Image.FromFile(picMonsterAsian);
            }
            if (radAmerican.Checked==true)
            {
                picM1.Image = System.Drawing.Image.FromFile(picMonsterAmerican);
                picM2.Image = System.Drawing.Image.FromFile(picMonsterAmerican);
                picM3.Image = System.Drawing.Image.FromFile(picMonsterAmerican);
            }

            //make all the objects invisible at first
            picH1.Visible = false;
            picH2.Visible = false;
            picH3.Visible = false;
            picM1.Visible = false;
            picM2.Visible = false;
            picM3.Visible = false;

            //enable all the buttons
            picBoat.Enabled = true;
            picH1.Enabled = true;
            picH2.Enabled = true;
            picH3.Enabled = true;
            picM1.Enabled = true;
            picM2.Enabled = true;
            picM3.Enabled = true;

            //show the objects according to difficulty
            if (cboMode.Text == "Easy")
            {
                picM1.Visible = true;
                picH1.Visible = true;
                
            }
            else if(cboMode.Text=="Normal")
            {
                picM1.Visible = true;
                picH1.Visible = true;
                picM2.Visible = true;
                picH2.Visible = true;
            }
            else if(cboMode.Text=="Hard")
            {
                picM1.Visible = true;
                picH1.Visible = true;
                picM2.Visible = true;
                picH2.Visible = true;
                picM3.Visible = true;
                picH3.Visible = true;
            }

            picBoat.Enabled = true;
            timer2.Enabled = true;

            //initialization of value for monsters and humans
            int i;
            for (i=0;i<3;i++)
            {
                aMonster[i] = "0000000";
                aHuman[i] = "0000000";
            }
            for (i=0; i<=cboMode.SelectedIndex; i++)
            {
                aMonster[i] = "0000001";
                aHuman[i] = "0000001";
            }

            boatFlag = 0;//direction of boat moving
            M1flag = 0; M2flag = 0; M3flag = 0; H1flag = 0; H2flag = 0; H3flag = 0;//human and monster boat boarding or leaving
            flag = 0;// win or lose

            //save the input to record values
            aNameRecord[mIndexRecord] = txtName.Text;
            aDifficultyRecord[mIndexRecord] = cboMode.SelectedItem.ToString();

            btnStart.Enabled = false;

            location = picBoat.Location;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtTime.Text = "0";
            boatFlag = 0;
            radAmerican.Checked = false;
            radAsian.Checked = false;

            btnStart.Enabled = true;

            timer2.Stop();
            time = 0;

            picBoat.Location = location;

            cboMode.SelectedIndex = -1;

            picH1.Location = locationRightH1;
            picH2.Location = locationRightH2;
            picH3.Location = locationRightH3;
            picM1.Location = locationRightM1;
            picM2.Location = locationRightM2;
            picM3.Location = locationRightM3;

            //make all the objects invisible at first
            picH1.Visible = false;
            picH2.Visible = false;
            picH3.Visible = false;
            picM1.Visible = false;
            picM2.Visible = false;
            picM3.Visible = false;
        }
        
        private void timer1_Tick(object sender, EventArgs e)//for all the moving staff....only
        {
            if (boatFlag==0)//if the boat is on the right
            {
                picBoat.Left = picBoat.Left - 20;

                if (M1flag==1)//if monster1 is on the boat
                {
                    picM1.Left = picM1.Left - 20;

                    if (aMonster[0]=="0000100")
                    {
                        aMonster[0] = "0100000";
                    }
                    else if(aMonster[0]=="0000010")
                    {
                        aMonster[0]="0010000";
                    }
                }

                if (M2flag == 1)
                {
                    picM2.Left = picM2.Left - 20;

                    if (aMonster[1] == "0000100")
                    {
                        aMonster[1] = "0100000";
                    }
                    else if (aMonster[1] == "0000010")
                    {
                        aMonster[1] = "0010000";
                    }
                }

                if (M3flag == 1)
                {
                    picM3.Left = picM3.Left - 20;

                    if (aMonster[2] == "0000100")
                    {
                        aMonster[2] = "0100000";
                    }
                    else if (aMonster[2] == "0000010")
                    {
                        aMonster[2] = "0010000";
                    }
                }

                if (H1flag == 1)
                {
                    picH1.Left = picH1.Left - 20;

                    if (aHuman[0] == "0000100")
                    {
                        aHuman[0] = "0100000";
                    }
                    else if (aHuman[0] == "0000010")
                    {
                        aHuman[0] = "0010000";
                    }
                }

                if (H2flag == 1)
                {
                    picH2.Left = picH2.Left - 20;

                    if (aHuman[1] == "0000100")
                    {
                        aHuman[1] = "0100000";
                    }
                    else if (aHuman[1] == "0000010")
                    {
                        aHuman[1] = "0010000";
                    }
                }

                if (H3flag == 1)
                {
                    picH3.Left = picH3.Left - 20;

                    if (aHuman[2] == "0000100")
                    {
                        aHuman[2] = "0100000";
                    }
                    else if (aHuman[2] == "0000010")
                    {
                        aHuman[2] = "0010000";
                    }
                }
            

                timee1();
                if (step == 20)
                {
                    timer1.Stop();
                    boatFlag = 1;

                    picBoat.Enabled = true;
                    picH1.Enabled = true;
                    picH2.Enabled = true;
                    picH3.Enabled = true;
                    picM1.Enabled = true;
                    picM2.Enabled = true;
                    picM3.Enabled = true;

                    if (algorithm() == false)
                    {
                        step = 20;//break the timer
                    }
                }
            }
            else
            {
                picBoat.Left = picBoat.Left + 20;

                if (M1flag == 1)
                {
                    picM1.Left = picM1.Left + 20;

                    if (aMonster[0] == "0100000")
                    {
                        aMonster[0] = "0000100";
                    }
                    else if (aMonster[0] == "0010000")
                    {
                        aMonster[0] = "0000010";
                    }
                }

                if (M2flag == 1)
                {
                    picM2.Left = picM2.Left + 20;

                    if (aMonster[1] == "0100000")
                    {
                        aMonster[1] = "0000100";
                    }
                    else if (aMonster[1] == "0010000")
                    {
                        aMonster[1] = "0000010";
                    }
                }
                if (M3flag == 1)
                {
                    picM3.Left = picM3.Left + 20;

                    if (aMonster[2] == "0100000")
                    {
                        aMonster[2] = "0000100";
                    }
                    else if (aMonster[2] == "0010000")
                    {
                        aMonster[2] = "0000010";
                    }
                }

                if (H1flag == 1)
                {
                    picH1.Left = picH1.Left + 20;

                    if (aHuman[0] == "0100000")
                    {
                        aHuman[0] = "0000100";
                    }
                    else if (aHuman[0] == "0010000")
                    {
                        aHuman[0] = "0000010";
                    }
                }

                if (H2flag == 1)
                {
                    picH2.Left = picH2.Left + 20;

                    if (aHuman[1] == "0100000")
                    {
                        aHuman[1] = "0000100";
                    }
                    else if (aHuman[1] == "0010000")
                    {
                        aHuman[1] = "0000010";
                    }
                }

                if (H3flag == 1)
                {
                    picH3.Left = picH3.Left + 20;

                    if (aHuman[2] == "0100000")
                    {
                        aHuman[2] = "0000100";
                    }
                    else if (aHuman[2] == "0010000")
                    {
                        aHuman[2] = "0000010";
                    }
                }

                timee1();

                if (step == 20)
                {
                    timer1.Stop();
                    boatFlag = 0;

                    picBoat.Enabled = true;
                    picH1.Enabled = true;
                    picH2.Enabled = true;
                    picH3.Enabled = true;
                    picM1.Enabled = true;
                    picM2.Enabled = true;
                    picM3.Enabled = true;

                    if (algorithm() == false)
                    {
                        step = 20;//break the timer
                    }
                }


            }
        }

        private void timee1()//helper method for timer1
        {
            timer1.Start();
            step++;
        }

        private void timer2_Tick(object sender, EventArgs e)//time counter
        {
            timee2();
            txtTime.Text = time.ToString();
        }

        private void timee2()//helper method for timer2
        {
            timer2.Start();
            time++;
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            lstOutput.Items.Clear();

            lstOutput.Items.Add("NAME".PadRight(20) + "DIFFICULTY".PadRight(20) + "TIME RECORD");
            lstOutput.Items.Add("=======================================================");
            int j;
            for (j = 0; j < mIndexRecord; j++)
            {
                lstOutput.Items.Add(aNameRecord[j].PadRight(23) + aDifficultyRecord[j].PadRight(22) + aTimeRecord[j].ToString());
            }
        }

        private void btnBest_Click(object sender, EventArgs e)
        {
            lstOutput.Items.Clear();
            int j,k=0,m=0, h=0,time1=9999,time2=9999,time3=9999;
           
            for (j=0; j<mIndexRecord;j++)
            {
                if (aDifficultyRecord[j]=="Easy"&& aTimeRecord[j] < time1)
                {
                    h = j;
                    time1 = aTimeRecord[j];
                }
                if (aDifficultyRecord[j] == "Normal" && (aTimeRecord[j] <= time2))
                {
                    k = j;
                    time2 = aTimeRecord[j];
                }
                if (aDifficultyRecord[j] == "Hard" && (aTimeRecord[j] <= time3))
                {
                    m = j;
                    time3 = aTimeRecord[j];
                }
            }
                lstOutput.Items.Add("NAME".PadRight(20) + "DIFFICULTY".PadRight(20) + "TIME RECORD");
                lstOutput.Items.Add("=======================================================");
            if(time1!=9999)
            {
                lstOutput.Items.Add(aNameRecord[h].PadRight(23) + "Easy".PadRight(22) + aTimeRecord[h].ToString());
            }
            if (time2 != 9999)
            {
                lstOutput.Items.Add(aNameRecord[k].PadRight(23) + "Normal".PadRight(22) + aTimeRecord[k].ToString());
            }
            if(time3!=9999)
            {
                lstOutput.Items.Add(aNameRecord[m].PadRight(23) + "Hard".PadRight(22) + aTimeRecord[m].ToString());
            }

        }

        //moving of human1
        private void picH1_MouseClick(object sender, MouseEventArgs e)
        {
            if (boatFlag == 0)//boat is on the right
            {
                if (H1flag == 0 && aHuman[0].IndexOf("1") == 6)//human1 is on position 6
                {
                    int j;
                    int l4 = 0, l5 = 0;
                    for (j = 0; j < 3; j++)
                    {
                        l4 = l4 + int.Parse(aHuman[j].Substring(4, 1)) + int.Parse(aMonster[j].Substring(4, 1));
                        l5 = l5 + int.Parse(aHuman[j].Substring(5, 1)) + int.Parse(aMonster[j].Substring(5, 1));
                    }

                    if (l4 == 0)
                    {
                        picH1.Location = location4H;
                        aHuman[0] = "0000100";
                        H1flag = 1;
                    }
                    else if (l5 == 0)
                    {
                        picH1.Location = location5H;
                        aHuman[0] = "0000010";
                        H1flag = 1;
                    }
                    else
                    {
                        DisplayMessage("Boat is full =.=");
                    }

                }
                else if (H1flag == 1)
                {
                    picH1.Location = locationRightH1;
                    aHuman[0] = "0000001";
                    H1flag = 0;
                }
            }
            else if(boatFlag==1)
            {
                if (H1flag == 0 && aHuman[0].IndexOf("1") == 0)
                {
                    int j;
                    int l1 = 0, l2 = 0;
                    for (j = 0; j < 3; j++)
                    {
                        l1 = l1 + int.Parse(aHuman[j].Substring(1, 1)) + int.Parse(aMonster[j].Substring(1, 1));
                        l2 = l2 + int.Parse(aHuman[j].Substring(2, 1)) + int.Parse(aMonster[j].Substring(2, 1));
                    }

                    if (l2 == 0)
                    {
                        picH1.Location = location2H;
                        aHuman[0] = "0010000";
                        H1flag = 1;
                    }
                    else if (l1 == 0)
                    {
                        picH1.Location = location1H;
                        aHuman[0] = "0100000";
                        H1flag = 1;
                    }
                    else
                    {
                        DisplayMessage("Boat is full =.=");
                    }

                }
                else if (H1flag == 1)
                {
                    picH1.Location = locationLeftH1;
                    aHuman[0] = "1000000";
                    H1flag = 0;

                    if (algorithm() == false)
                    {
                        return;
                    }
                    //whether the user wins or loses it will return
                }
            }

        }

        private void form_Load(object sender, EventArgs e)
        {
            StreamReader sr = null;
            string line;
            string []parts;
            if(File.Exists(mfile)==false)
            {
                DisplayMessage("The file does not exist");
                return;
            }
            try
            {
                sr = new StreamReader(mfile);
                while (sr.Peek()!=-1)
                {
                    line = sr.ReadLine();
                    parts = line.Split('\t');
                    aNameRecord[mIndexRecord] = parts[0];
                    aDifficultyRecord[mIndexRecord] = parts[1];
                    aTimeRecord[mIndexRecord] = int.Parse(parts[2]);
                    mIndexRecord++;
                }
            }
            catch(Exception ex)
            {
                DisplayMessage(ex.Message);
                return;
            }
            finally
            {
                if(sr!=null)
                {
                    sr.Close();
                }
            }
        }

        private void form_FormClosing(object sender, FormClosingEventArgs e)
        {
            StreamWriter sw= null;
            try
            {
                if(MessageBox.Show("Are you sure?",Text,MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.No)
                {
                    e.Cancel = true;
                    return;
                }

                sw = new StreamWriter(mfile);
                int j;
                for (j = 0; j < mIndexRecord; j++)
                {
                    sw.WriteLine(aNameRecord[j] + '\t' + aDifficultyRecord[j] + '\t' + aTimeRecord[j].ToString());
                }
            }
            catch (Exception ex)
            {
                DisplayMessage(ex.Message);
                return;
            }
            finally
            {
                if (sw != null)
                sw.Close();
            }
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            Array.Sort(aTimeRecord,aNameRecord,0,mIndexRecord);
            Array.Sort(aTimeRecord2,aDifficultyRecord ,0, mIndexRecord);
            lstOutput.Items.Clear();

            lstOutput.Items.Add("NAME".PadRight(20) + "DIFFICULTY".PadRight(20) + "TIME RECORD");
            lstOutput.Items.Add("=======================================================");
            int j;
            for (j = 0; j < mIndexRecord; j++)
            {
                lstOutput.Items.Add(aNameRecord[j].PadRight(23) + aDifficultyRecord[j].PadRight(22) + aTimeRecord[j].ToString());
            }
        }

        private void picH2_MouseClick(object sender, MouseEventArgs e)
        {
            if (boatFlag == 0)
            {
                if (H2flag == 0 && aHuman[1].IndexOf("1") == 6)
                {

                    int j;
                    int l4 = 0, l5 = 0;
                    for (j = 0; j < 3; j++)
                    {
                        l4 = l4 + int.Parse(aHuman[j].Substring(4, 1)) + int.Parse(aMonster[j].Substring(4, 1));
                        l5 = l5 + int.Parse(aHuman[j].Substring(5, 1)) + int.Parse(aMonster[j].Substring(5, 1));
                    }

                    if (l4 == 0)
                    {
                        picH2.Location = location4H;
                        aHuman[1] = "0000100";
                        H2flag = 1;
                    }
                    else if (l5 == 0)
                    {
                        picH2.Location = location5H;
                        aHuman[1] = "0000010";
                        H2flag = 1;
                    }
                    else
                    {
                        DisplayMessage("Boat is full =.=");
                    }

                }
                else if (H2flag == 1)
                {
                    picH2.Location = locationRightH2;
                    aHuman[1] = "0000001";
                    H2flag = 0;
                }
            }
            else if (boatFlag==1)
            {
                if (H2flag == 0 && aHuman[1].IndexOf("1") == 0)
                {
                    int j;
                    int l1 = 0, l2 = 0;
                    for (j = 0; j < 3; j++)
                    {
                        l1 = l1 + int.Parse(aHuman[j].Substring(1, 1)) + int.Parse(aMonster[j].Substring(1, 1));
                        l2 = l2 + int.Parse(aHuman[j].Substring(2, 1)) + int.Parse(aMonster[j].Substring(2, 1));
                    }

                    if (l2 == 0)
                    {
                        picH2.Location = location2H;
                        aHuman[1] = "0010000";
                        H2flag = 1;
                    }
                    else if (l1 == 0)
                    {
                        picH2.Location = location1H;
                        aHuman[1] = "0100000";
                        H2flag = 1;
                    }
                    else
                    {
                        DisplayMessage("Boat is full =.=");
                    }

                }
                else if (H2flag == 1)
                {
                    picH2.Location = locationLeftH2;
                    aHuman[1] = "1000000";
                    H2flag = 0;

                    if (algorithm() == false)
                    {
                        return;
                    }
                    //whether the user wins or loses it will return
                }
            }
        }

        private void picH3_MouseClick_1(object sender, MouseEventArgs e)
        {
            if (boatFlag == 0)
            {
                if (H3flag == 0 && aHuman[2].IndexOf("1") == 6)
                {

                    int j;
                    int l4 = 0, l5 = 0;
                    for (j = 0; j < 3; j++)
                    {
                        l4 = l4 + int.Parse(aHuman[j].Substring(4, 1)) + int.Parse(aMonster[j].Substring(4, 1));
                        l5 = l5 + int.Parse(aHuman[j].Substring(5, 1)) + int.Parse(aMonster[j].Substring(5, 1));
                    }

                    if (l4 == 0)
                    {
                        picH3.Location = location4H;
                        aHuman[2] = "0000100";
                        H3flag = 1;
                    }
                    else if (l5 == 0)
                    {
                        picH3.Location = location5H;
                        aHuman[2] = "0000010";
                        H3flag = 1;
                    }
                    else
                    {
                        DisplayMessage("Boat is full =.=");
                    }

                }
                else if (H3flag == 1)
                {
                    picH3.Location = locationRightH3;
                    aHuman[2] = "0000001";
                    H3flag = 0;
                }
            }
            else if(boatFlag==1)
            {
                if (H3flag == 0 && aHuman[2].IndexOf("1")==0)
                {
                    int j;
                    int l1 = 0, l2 = 0;
                    for (j = 0; j < 3; j++)
                    {
                        l1 = l1 + int.Parse(aHuman[j].Substring(1, 1)) + int.Parse(aMonster[j].Substring(1, 1));
                        l2 = l2 + int.Parse(aHuman[j].Substring(2, 1)) + int.Parse(aMonster[j].Substring(2, 1));
                    }

                    if (l2 == 0)
                    {
                        picH3.Location = location2H;
                        aHuman[2] = "0010000";
                        H3flag = 1;
                    }
                    else if (l1 == 0)
                    {
                        picH3.Location = location1H;
                        aHuman[2] = "0100000";
                        H3flag = 1;
                    }
                    else
                    {
                        DisplayMessage("Boat is full =.=");
                    }

                }
                else if (H3flag == 1)
                {
                    picH3.Location = locationLeftH3;
                    aHuman[2] = "1000000";
                    H3flag = 0;

                    if (algorithm() == false)
                    {
                        return;
                    }
                    //whether the user wins or loses it will return
                }
            }
        }

        private void picM1_MouseClick(object sender, MouseEventArgs e)
        {
            if (boatFlag == 0)
            {
                if (M1flag == 0 && aMonster[0].IndexOf("1") == 6)
                {
                    int j;
                    int l4 = 0, l5 = 0;
                    for (j = 0; j < 3; j++)
                    {
                        l4 = l4 + int.Parse(aHuman[j].Substring(4, 1)) + int.Parse(aMonster[j].Substring(4, 1));
                        l5 = l5 + int.Parse(aHuman[j].Substring(5, 1)) + int.Parse(aMonster[j].Substring(5, 1));
                    }

                    if (l4 == 0)
                    {
                        picM1.Location = location4M;
                        aMonster[0] = "0000100";
                        M1flag = 1;
                    }
                    else if (l5 == 0)
                    {
                        picM1.Location = location5M;
                        aMonster[0] = "0000010";
                        M1flag = 1;
                    }
                    else
                    {
                        DisplayMessage("Boat is full =.=");
                    }

                }
                else if (M1flag == 1)
                {
                    picM1.Location = locationRightM1;
                    aMonster[0] = "0000001";
                    M1flag = 0;
                }
            }
            else if(boatFlag==1)
            {
                if (M1flag == 0 && aMonster[0].IndexOf("1") == 0)
                {
                    int j;
                    int l1 = 0, l2 = 0;
                    for (j = 0; j < 3; j++)
                    {
                        l1 = l1 + int.Parse(aHuman[j].Substring(1, 1)) + int.Parse(aMonster[j].Substring(1, 1));
                        l2 = l2 + int.Parse(aHuman[j].Substring(2, 1)) + int.Parse(aMonster[j].Substring(2, 1));
                    }

                    if (l2 == 0)
                    {
                        picM1.Location = location2M;
                        aMonster[0] = "0010000";
                        M1flag = 1;
                    }
                    else if (l1 == 0)
                    {
                        picM1.Location = location1M;
                        aMonster[0] = "0100000";
                        M1flag = 1;
                    }
                    else
                    {
                        DisplayMessage("Boat is full =.=");
                    }

                }
                else if (M1flag == 1)
                {
                    picM1.Location = locationLeftM1;
                    aMonster[0] = "1000000";
                    M1flag = 0;

                    if (algorithm() == false)
                    {
                        return;
                    }
                    //whether the user wins or loses it will return
                }
            }
        }

        private void picM2_MouseClick(object sender, MouseEventArgs e)
        {
            if (boatFlag == 0)
            {
                if (M2flag == 0 && aMonster[1].IndexOf("1") == 6)
                {

                    int j;
                    int l4 = 0, l5 = 0;
                    for (j = 0; j < 3; j++)
                    {
                        l4 = l4 + int.Parse(aHuman[j].Substring(4, 1)) + int.Parse(aMonster[j].Substring(4, 1));
                        l5 = l5 + int.Parse(aHuman[j].Substring(5, 1)) + int.Parse(aMonster[j].Substring(5, 1));
                    }

                    if (l4 == 0)
                    {
                        picM2.Location = location4M;
                        aMonster[1] = "0000100";
                        M2flag = 1;
                    }
                    else if (l5 == 0)
                    {
                        picM2.Location = location5M;
                        aMonster[1] = "0000010";
                        M2flag = 1;
                    }
                    else
                    {
                        DisplayMessage("Boat is full =.=");
                    }

                }
                else if (M2flag == 1)
                {
                    picM2.Location = locationRightM2;
                    aMonster[1] = "0000001";
                    M2flag = 0;
                }
            }
            else if(boatFlag==1)
            {
                if (M2flag == 0 && aMonster[1].IndexOf("1") == 0)
                {
                    int j;
                    int l1 = 0, l2 = 0;
                    for (j = 0; j < 3; j++)
                    {
                        l1 = l1 + int.Parse(aHuman[j].Substring(1, 1)) + int.Parse(aMonster[j].Substring(1, 1));
                        l2 = l2 + int.Parse(aHuman[j].Substring(2, 1)) + int.Parse(aMonster[j].Substring(2, 1));
                    }

                    if (l2 == 0)
                    {
                        picM2.Location = location2M;
                        aMonster[1] = "0010000";
                        M2flag = 1;
                    }
                    else if (l1 == 0)
                    {
                        picM2.Location = location1M;
                        aMonster[1] = "0100000";
                        M2flag = 1;
                    }
                    else
                    {
                        DisplayMessage("Boat is full =.=");
                    }

                }
                else if (M2flag == 1)
                {
                    picM2.Location = locationLeftM2;
                    aMonster[1] = "1000000";
                    M2flag = 0;

                    if (algorithm() == false)
                    {
                        return;
                    }
                    //whether the user wins or loses it will return
                }
            }
        }

        private void picM3_Click(object sender, EventArgs e)
        {
            if (boatFlag==0)
            {
                if (M3flag == 0 && aMonster[2].IndexOf("1") == 6)
                {
                    
                    int j;
                    int l4=0,l5=0;
                    for (j = 0; j < 3; j++)
                    {
                        l4 = l4 + int.Parse(aHuman[j].Substring(4, 1)) + int.Parse(aMonster[j].Substring(4, 1));
                        l5 = l5 + int.Parse(aHuman[j].Substring(5, 1)) + int.Parse(aMonster[j].Substring(5, 1));
                    }

                    if (l4==0)
                    {                       
                        picM3.Location = location4M;
                        aMonster[2] = "0000100";
                        M3flag = 1;
                    }
                    else if (l5==0)
                    {
                        picM3.Location = location5M;
                        aMonster[2] = "0000010";
                        M3flag = 1;
                    }
                    else
                    {
                        DisplayMessage("Boat is full =.=");
                    }
                   
                }
                else if (M3flag == 1)
                {
                    picM3.Location = locationRightM3;
                    aMonster[2] = "0000001";
                    M3flag = 0;
                }
            }
            else if(boatFlag==1)
            {
                if (M3flag == 0 && aMonster[2].IndexOf("1") == 0)
                {
                    int j;
                    int l1 = 0, l2 = 0;
                    for (j = 0; j < 3; j++)
                    {
                        l1 = l1 + int.Parse(aHuman[j].Substring(1, 1)) + int.Parse(aMonster[j].Substring(1, 1));
                        l2 = l2 + int.Parse(aHuman[j].Substring(2, 1)) + int.Parse(aMonster[j].Substring(2, 1));
                    }

                    if (l2 == 0)
                    {
                        picM3.Location = location2M;
                        aMonster[2] = "0010000";
                        M3flag = 1;
                    }
                    else if (l1 == 0)
                    {
                        picM3.Location = location1M;
                        aMonster[2] = "0100000";
                        M3flag = 1;
                    }
                    else
                    {
                        DisplayMessage("Boat is full =.=");
                    }

                }
                else if (M3flag == 1)
                {
                    picM3.Location = locationLeftM3;
                    aMonster[2] = "1000000";
                    M3flag = 0;

                    if (algorithm() == false)
                    {
                        return;
                    }
                    //whether the user wins or loses it will return
                }
            }
        }


    }
}
