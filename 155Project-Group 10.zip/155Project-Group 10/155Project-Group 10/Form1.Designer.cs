﻿namespace _155Project_Group_10
{
    partial class form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form));
            this.label1 = new System.Windows.Forms.Label();
            this.cboMode = new System.Windows.Forms.ComboBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.radAsian = new System.Windows.Forms.RadioButton();
            this.radAmerican = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lstOutput = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSort = new System.Windows.Forms.Button();
            this.btnBest = new System.Windows.Forms.Button();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.txtTime = new System.Windows.Forms.TextBox();
            this.picBoat = new System.Windows.Forms.PictureBox();
            this.picM1 = new System.Windows.Forms.PictureBox();
            this.picH1 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.picM2 = new System.Windows.Forms.PictureBox();
            this.picM3 = new System.Windows.Forms.PictureBox();
            this.picH2 = new System.Windows.Forms.PictureBox();
            this.picH3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lbltime = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picM1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picH1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picM2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picM3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picH2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picH3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(640, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cross the river";
            // 
            // cboMode
            // 
            this.cboMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMode.FormattingEnabled = true;
            this.cboMode.Items.AddRange(new object[] {
            "Easy",
            "Normal",
            "Hard"});
            this.cboMode.Location = new System.Drawing.Point(159, 130);
            this.cboMode.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cboMode.Name = "cboMode";
            this.cboMode.Size = new System.Drawing.Size(233, 24);
            this.cboMode.TabIndex = 10;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(173, 234);
            this.btnStart.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(159, 44);
            this.btnStart.TabIndex = 11;
            this.btnStart.Text = "&Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 20;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // radAsian
            // 
            this.radAsian.AutoSize = true;
            this.radAsian.Location = new System.Drawing.Point(159, 82);
            this.radAsian.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radAsian.Name = "radAsian";
            this.radAsian.Size = new System.Drawing.Size(97, 21);
            this.radAsian.TabIndex = 12;
            this.radAsian.TabStop = true;
            this.radAsian.Text = "Asian style";
            this.radAsian.UseVisualStyleBackColor = true;
            // 
            // radAmerican
            // 
            this.radAmerican.AutoSize = true;
            this.radAmerican.Location = new System.Drawing.Point(267, 82);
            this.radAmerican.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radAmerican.Name = "radAmerican";
            this.radAmerican.Size = new System.Drawing.Size(123, 21);
            this.radAmerican.TabIndex = 13;
            this.radAmerican.TabStop = true;
            this.radAmerican.Text = "American Style";
            this.radAmerican.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 134);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 17);
            this.label2.TabIndex = 14;
            this.label2.Text = "Difficulty: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 82);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 17);
            this.label3.TabIndex = 15;
            this.label3.Text = "Characters: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 33);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 17);
            this.label4.TabIndex = 16;
            this.label4.Text = "Player Name: ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnReset);
            this.groupBox1.Controls.Add(this.txtName);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.radAmerican);
            this.groupBox1.Controls.Add(this.radAsian);
            this.groupBox1.Controls.Add(this.btnStart);
            this.groupBox1.Controls.Add(this.cboMode);
            this.groupBox1.Location = new System.Drawing.Point(51, 36);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(563, 326);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Game initialization";
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(415, 242);
            this.btnReset.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(100, 28);
            this.btnReset.TabIndex = 18;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(159, 30);
            this.txtName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(233, 22);
            this.txtName.TabIndex = 17;
            // 
            // lstOutput
            // 
            this.lstOutput.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstOutput.FormattingEnabled = true;
            this.lstOutput.ItemHeight = 17;
            this.lstOutput.Location = new System.Drawing.Point(51, 25);
            this.lstOutput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lstOutput.Name = "lstOutput";
            this.lstOutput.Size = new System.Drawing.Size(507, 191);
            this.lstOutput.TabIndex = 18;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnSort);
            this.groupBox2.Controls.Add(this.btnBest);
            this.groupBox2.Controls.Add(this.btnDisplay);
            this.groupBox2.Controls.Add(this.lstOutput);
            this.groupBox2.Location = new System.Drawing.Point(920, 27);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(572, 350);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Records";
            // 
            // btnSort
            // 
            this.btnSort.Location = new System.Drawing.Point(271, 258);
            this.btnSort.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSort.Name = "btnSort";
            this.btnSort.Size = new System.Drawing.Size(100, 28);
            this.btnSort.TabIndex = 21;
            this.btnSort.Text = "&Sort";
            this.btnSort.UseVisualStyleBackColor = true;
            this.btnSort.Click += new System.EventHandler(this.btnSort_Click);
            // 
            // btnBest
            // 
            this.btnBest.Location = new System.Drawing.Point(415, 258);
            this.btnBest.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnBest.Name = "btnBest";
            this.btnBest.Size = new System.Drawing.Size(100, 28);
            this.btnBest.TabIndex = 20;
            this.btnBest.Text = "&Best Player";
            this.btnBest.UseVisualStyleBackColor = true;
            this.btnBest.Click += new System.EventHandler(this.btnBest_Click);
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(127, 258);
            this.btnDisplay.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(100, 28);
            this.btnDisplay.TabIndex = 19;
            this.btnDisplay.Text = "&Display";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // txtTime
            // 
            this.txtTime.Location = new System.Drawing.Point(780, 110);
            this.txtTime.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTime.Name = "txtTime";
            this.txtTime.ReadOnly = true;
            this.txtTime.Size = new System.Drawing.Size(103, 22);
            this.txtTime.TabIndex = 20;
            // 
            // picBoat
            // 
            this.picBoat.BackColor = System.Drawing.Color.Transparent;
            this.picBoat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picBoat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picBoat.Enabled = false;
            this.picBoat.Image = ((System.Drawing.Image)(resources.GetObject("picBoat.Image")));
            this.picBoat.Location = new System.Drawing.Point(927, 548);
            this.picBoat.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picBoat.Name = "picBoat";
            this.picBoat.Size = new System.Drawing.Size(193, 37);
            this.picBoat.TabIndex = 21;
            this.picBoat.TabStop = false;
            this.picBoat.Click += new System.EventHandler(this.picBoat_Click_1);
            // 
            // picM1
            // 
            this.picM1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picM1.Image = ((System.Drawing.Image)(resources.GetObject("picM1.Image")));
            this.picM1.InitialImage = null;
            this.picM1.Location = new System.Drawing.Point(1261, 444);
            this.picM1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picM1.Name = "picM1";
            this.picM1.Size = new System.Drawing.Size(61, 105);
            this.picM1.TabIndex = 22;
            this.picM1.TabStop = false;
            this.picM1.Visible = false;
            this.picM1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.picM1_MouseClick);
            // 
            // picH1
            // 
            this.picH1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picH1.Image = ((System.Drawing.Image)(resources.GetObject("picH1.Image")));
            this.picH1.Location = new System.Drawing.Point(1331, 468);
            this.picH1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picH1.Name = "picH1";
            this.picH1.Size = new System.Drawing.Size(48, 81);
            this.picH1.TabIndex = 25;
            this.picH1.TabStop = false;
            this.picH1.Visible = false;
            this.picH1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.picH1_MouseClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.LightBlue;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.DataBindings.Add(new System.Windows.Forms.Binding("ForeColor", global::_155Project_Group_10.Properties.Settings.Default, "qwer", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.pictureBox1.ForeColor = global::_155Project_Group_10.Properties.Settings.Default.qwer;
            this.pictureBox1.Location = new System.Drawing.Point(387, 585);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(745, 63);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // picM2
            // 
            this.picM2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picM2.Image = ((System.Drawing.Image)(resources.GetObject("picM2.Image")));
            this.picM2.InitialImage = null;
            this.picM2.Location = new System.Drawing.Point(1191, 444);
            this.picM2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picM2.Name = "picM2";
            this.picM2.Size = new System.Drawing.Size(63, 105);
            this.picM2.TabIndex = 28;
            this.picM2.TabStop = false;
            this.picM2.Visible = false;
            this.picM2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.picM2_MouseClick);
            // 
            // picM3
            // 
            this.picM3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picM3.Image = ((System.Drawing.Image)(resources.GetObject("picM3.Image")));
            this.picM3.InitialImage = null;
            this.picM3.Location = new System.Drawing.Point(1121, 444);
            this.picM3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picM3.Name = "picM3";
            this.picM3.Size = new System.Drawing.Size(61, 105);
            this.picM3.TabIndex = 29;
            this.picM3.TabStop = false;
            this.picM3.Visible = false;
            this.picM3.Click += new System.EventHandler(this.picM3_Click);
            // 
            // picH2
            // 
            this.picH2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picH2.Image = ((System.Drawing.Image)(resources.GetObject("picH2.Image")));
            this.picH2.Location = new System.Drawing.Point(1387, 468);
            this.picH2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picH2.Name = "picH2";
            this.picH2.Size = new System.Drawing.Size(48, 81);
            this.picH2.TabIndex = 30;
            this.picH2.TabStop = false;
            this.picH2.Visible = false;
            this.picH2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.picH2_MouseClick);
            // 
            // picH3
            // 
            this.picH3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picH3.Image = ((System.Drawing.Image)(resources.GetObject("picH3.Image")));
            this.picH3.Location = new System.Drawing.Point(1443, 468);
            this.picH3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picH3.Name = "picH3";
            this.picH3.Size = new System.Drawing.Size(48, 81);
            this.picH3.TabIndex = 31;
            this.picH3.TabStop = false;
            this.picH3.Visible = false;
            this.picH3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.picH3_MouseClick_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.pictureBox2.Location = new System.Drawing.Point(1121, 551);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(368, 96);
            this.pictureBox2.TabIndex = 32;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.pictureBox3.Location = new System.Drawing.Point(19, 551);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(368, 96);
            this.pictureBox3.TabIndex = 33;
            this.pictureBox3.TabStop = false;
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltime.Location = new System.Drawing.Point(693, 107);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(56, 25);
            this.lbltime.TabIndex = 34;
            this.lbltime.Text = "Time";
            // 
            // form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1515, 668);
            this.Controls.Add(this.lbltime);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.picH3);
            this.Controls.Add(this.picH2);
            this.Controls.Add(this.picM3);
            this.Controls.Add(this.picM2);
            this.Controls.Add(this.picH1);
            this.Controls.Add(this.picM1);
            this.Controls.Add(this.picBoat);
            this.Controls.Add(this.txtTime);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "form";
            this.Text = "155Project-Group 10";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.form_FormClosing);
            this.Load += new System.EventHandler(this.form_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBoat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picM1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picH1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picM2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picM3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picH2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picH3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox cboMode;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.RadioButton radAsian;
        private System.Windows.Forms.RadioButton radAmerican;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.ListBox lstOutput;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnBest;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.PictureBox picBoat;
        private System.Windows.Forms.PictureBox picM1;
        private System.Windows.Forms.PictureBox picH1;
        private System.Windows.Forms.PictureBox picM2;
        private System.Windows.Forms.PictureBox picM3;
        private System.Windows.Forms.PictureBox picH2;
        private System.Windows.Forms.PictureBox picH3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label lbltime;
        private System.Windows.Forms.Button btnSort;
    }
}

