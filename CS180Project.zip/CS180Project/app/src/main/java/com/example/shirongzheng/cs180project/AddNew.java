package com.example.shirongzheng.cs180project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class AddNew extends AppCompatActivity {
Button set;
EditText name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new);
        set=findViewById(R.id.btnset);
        name=findViewById(R.id.edtenter);
        set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Counter counter=MainActivity.counters.get(MainActivity.index-1);
                counter.setName(name.getText().toString());
                counter.setCount(0);
                MainActivity.counternames.add(counter.getName()+": "+String.valueOf(counter.getCount()));
                Intent intent=new Intent(view.getContext(),MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
