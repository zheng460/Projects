package com.example.shirongzheng.cs180project;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Counter extends AppCompatActivity {

    //@Override
    EditText txtcount;
    Button btncount;
    Button btndone;
    private int id;
    private int count;
    private String name;
    private int index;
    public Counter(int id,String name,int count){
        this.name=name;
        this.count=count;
        this.id=id;
    }
    public Counter(int id){
        this.name="New Counter:";
        this.count=0;
        this.id=id;
    }
    public Counter(){
        this.name="New Counter";
        this.count=0;
        this.id=MainActivity.index;
    }
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counter);
        btndone=(Button)findViewById(R.id.btndone);
        txtcount=(EditText)findViewById(R.id.txtcount) ;
        btncount=(Button)findViewById(R.id.btncount);
        Bundle recieve = getIntent().getExtras();
        index = recieve.getInt("send");
        int value;
        value=MainActivity.counters.get(index).getCount();
        txtcount.setText(String.valueOf(value));
        btndone.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int newvalue=Integer.parseInt(txtcount.getText().toString());
                MainActivity.counters.get(index).setCount(newvalue);
                Intent intent=new Intent(view.getContext(),MainActivity.class);
                startActivity(intent);
            }

        });
        btncount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle receive = getIntent().getExtras();
                int value;
                int newvalue=Integer.parseInt(txtcount.getText().toString());
                MainActivity.counters.get(index).setCount(newvalue);
                value=MainActivity.counters.get(index).getCount();
                value=value+1;
                MainActivity.counters.get(index).setCount(value);
                txtcount.setText(String.valueOf(value));
            }
        });
        //count=(TextView)
    }
    public int getCount(){
        return count;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name=name;
    }
    public void setCount(int count){
        this.count=count;
    }


}
